import zipfile
import os

def Zip(SrcDir,zfile):
    headpath =os.path.dirname(SrcDir)
    f=zipfile.ZipFile(zfile,'w',zipfile.ZIP_DEFLATED)
    for fileroot,filedir,filelist in os.walk(SrcDir):
        filePath = fileroot.replace(headpath,'')
        print('filepath=',filePath)
        f.write(fileroot,filePath)
        for file in filelist:
            print('{} is zip to {}'.format(file,filePath+'/'+file))
            f.write(os.path.join(fileroot,file),os.path.join(filePath,file))
def t1():
    SrcDir = '/home/zhuzi166/workspace/project/Myproject'
    Zip(SrcDir,'ttt.zip')

if __name__ == '__main__':
    t1()