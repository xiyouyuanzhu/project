import os
import sys
import shutil

def Test_install():
    # 调用 shutil.rmtree 地柜删除所有东西
   #调用shuril .copytree 地柜拷贝至文件内
   pass



def main():
    pass

if __name__ == '__main__':
    pass